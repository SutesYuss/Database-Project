package osu.cse3241;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * <h1>CSE3241 Introduction to Database Systems - Sample Java application.</h1>
 *
 * <p>
 * Sample app to be used as guidance and a foundation for students of CSE3241
 * Introduction to Database Systems at The Ohio State University.
 * </p>
 *
 * <h2>!!! - Vulnerable to SQL injection - !!!</h2>
 * <p>
 * Correct the code so that it is not vulnerable to a SQL injection attack.
 * ("Parameter substitution" is the usual way to do this.)
 * </p>
 *
 * <p>
 * Class is written in Java SE 8 and in a procedural style. Implement a
 * constructor if you build this app out in OOP style.
 * </p>
 * <p>
 * Modify and extend this app as necessary for your project.
 * </p>
 *
 * <h2>Language Documentation:</h2>
 * <ul>
 * <li><a href="https://docs.oracle.com/javase/8/docs/">Java SE 8</a></li>
 * <li><a href="https://docs.oracle.com/javase/8/docs/api/">Java SE 8
 * API</a></li>
 * <li><a href=
 * "https://docs.oracle.com/javase/8/docs/technotes/guides/jdbc/">Java JDBC
 * API</a></li>
 * <li><a href="https://www.sqlite.org/docs.html">SQLite</a></li>
 * <li><a href="http://www.sqlitetutorial.net/sqlite-java/">SQLite Java
 * Tutorial</a></li>
 * </ul>
 *
 * <h2>MIT License</h2>
 *
 * <em>Copyright (c) 2019 Leon J. Madrid, Jeff Hachtel</em>
 *
 * <p>
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * </p>
 *
 *
 * @author Leon J. Madrid (madrid.1), Jeff Hachtel (hachtel.5)
 *
 */

public class DatabaseSql {

    /**
     * The database file name.
     *
     * Make sure the database file is in the root folder of the project if you
     * only provide the name and extension.
     *
     * Otherwise, you will need to provide an absolute path from your C: drive
     * or a relative path from the folder this class is in.
     */
    private static String DATABASE = "LibraryDatabase.db";

    /**
     * The query statement to be executed.
     *
     * Remember to include the semicolon at the end of the statement string.
     * (Not all programming languages and/or packages require the semicolon
     * (e.g., Python's SQLite3 library))
     */
    private static String sqlStatement1 = "SELECT * FROM ARTIST WHERE Fname=? AND Lname = ?;";

    private static String sqlStatement2 = "SELECT * FROM TRACK WHERE Title=?;";

    private static String sqlStatement3 = "INSERT INTO ARTIST (Art_ID, Fname, Lname) VALUES(?, ?, ?);";

    private static String sqlStatement31 = "SELECT * FROM Movie;";

    private static String sqlStatement4 = "INSERT INTO Ordered_Media (Media_ID, Type, Form, Title, Price, ArrivalDate) VALUES(?, 'Movie', 'Physical', ?, ?, ?);";

    private static String sqlStatement41 = "INSERT INTO Ordered_Media (Media_ID, Type, Form, Title, Price, ArrivalDate) VALUES(?, 'Movie', 'Physical', ?, ?, ?);";

    private static String sqlStatement51 = "INSERT INTO Movie VALUES (?, ?, ?, ?, ?, ?, ?);";

    private static String sqlStatement58 = "DELETE FROM Ordered_Media WHERE Title = ?;";

    private static String sqlStatement52 = "INSERT INTO Book VALUES(?, ?, ?, ?, ?, ?, ?);";

    private static String sqlStatement53 = "INSERT INTO Album VALUES(?, ?, ?, ?, ?, ?, ?);";

    private static String sqlStatement54 = "INSERT INTO Track VALUES(?, ?, ?, ?, ?, ?);";

    private static String sqlStatement55 = "INSERT INTO Audiobook VALUES(?, ?, ?, ?, ?, ?, ?, ?);";

    private static String sqlStatement56 = "INSERT INTO Media VALUES(?, 'Physical', ?, 'Columbus', 'Ordered', ?);";

    private static String sqlStatement57 = "UPDATE Media SET Availability = 'Available' WHERE Title = ?;";

    private static String sqlStatement6 = "UPDATE ARTIST SET Lname = ? WHERE Fname = ? AND Lname = ?;";

    private static String sqlStatement7 = "UPDATE ARTIST SET Art_ID = ? WHERE Fname = ? AND Lname = ?;";

    private static String sqlStatement8 = "UPDATE ARTIST SET Fname = ? WHERE Fname = ? AND Lname = ?;";

    private static String sqlStatement9 = "SELECT Track.Title, Track.Year FROM Artist, Track WHERE Artist.Art_ID = Track.Art_ID AND Artist.Fname = ? AND Artist.Lname = ? AND Year < ?;";

    private static String sqlStatement10 = "SELECT COUNT(CheckedOutItems.Media_ID) FROM CARD_HOLDER, CheckedOutItems, ALBUM WHERE CheckedOutItems.Media_ID = ALBUM.Media_ID AND CheckedOutItems.L_ID = CARD_HOLDER.L_ID AND CARD_HOLDER.Fname = ? AND CARD_HOLDER.Lname = ?;";

    private static String sqlStatement11 = "SELECT Fname, Lname FROM ACTOR AS A, FEATURES AS F, CheckedOutItems AS C, MOVIE AS M WHERE A.Act_ID = F.Act_ID AND F.M_ID = M.M_ID AND M.Media_ID = C.Media_ID GROUP BY Fname ORDER BY COUNT(*) DESC LIMIT 1;";

    private static String sqlStatement12 = "SELECT AR.Fname, AR.Lname FROM ARTIST AS AR, CheckedOutItems AS C, ALBUM AS A, TRACK AS T WHERE A.Art_ID = AR.Art_ID AND C.Media_ID = A.Media_ID AND T.Art_ID = A.Art_ID GROUP BY AR.Fname HAVING MAX(T.Length) ORDER BY COUNT(*) DESC LIMIT 1;";

    private static String sqlStatement13 = "SELECT Fname, Lname, COUNT(CheckedOutItems.Media_ID) FROM CARD_HOLDER, CheckedOutItems, MOVIE WHERE CARD_HOLDER.L_ID = CheckedOutItems.L_ID AND MOVIE.Media_ID = CheckedOutItems.Media_ID GROUP BY CARD_HOLDER.L_ID HAVING MAX(MOVIE.Media_ID) ORDER BY COUNT(*) DESC LIMIT 1;";

    private static String sqlStatement14 = "UPDATE Media SET Copies = Copies + ? WHERE Title = ?;";

    /**
     * Connects to the database if it exists, creates it if it does not, and
     * returns the connection object.
     *
     * @param databaseFileName
     *            the database file name
     * @return a connection object to the designated database
     */
    public static Connection initializeDB(String databaseFileName) {
        /**
         * The "Connection String" or "Connection URL".
         *
         * "jdbc:sqlite:" is the "subprotocol". (If this were a SQL Server
         * database it would be "jdbc:sqlserver:".)
         */
        String url = "jdbc:sqlite:" + databaseFileName;
        Connection conn = null; // If you create this variable inside the Try block it will be out of scope
        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                // Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out
                        .println("The driver name is " + meta.getDriverName());
                System.out.println(
                        "The connection to the database was successful.");
            } else {
                // Provides some feedback in case the connection failed but did not throw an exception.
                System.out.println("Null Connection");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out
                    .println("There was a problem connecting to the database.");
        }
        return conn;
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery(Connection conn, String sql, String in1,
            String in2) {

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);

            ResultSet rs = ps.executeQuery();

            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery0(Connection conn, String sql) {

        try {
            PreparedStatement ps = conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery1(Connection conn, String sql, String input) {

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, input);

            ResultSet rs = ps.executeQuery();

            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery12(Connection conn, String sql, String input) {

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, input);

            ps.execute();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery2(Connection conn, String sql, String in1,
            String in2, String in3) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);
            ps.setString(3, in3);

            ps.execute();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery3(Connection conn, String sql, String in1,
            String in2) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);

            ps.executeUpdate();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery4(Connection conn, String sql, String in1,
            String in2, String in3) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);
            ps.setString(3, in3);

            ResultSet rs = ps.executeQuery();

            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery5(Connection conn, String sql, String in1,
            String in2, String in3, String in4) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);
            ps.setString(3, in3);
            ps.setString(4, in4);

            ps.execute();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery6(Connection conn, String sql, String in1,
            String in2, String in3, String in4) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);
            ps.setString(3, in3);
            ps.setString(4, in4);

            ps.execute();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery7(Connection conn, String sql, String in1,
            String in2, String in3, String in4, String in5, String in6,
            String in7) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);
            ps.setString(3, in3);
            ps.setString(4, in4);
            ps.setString(5, in5);
            ps.setString(6, in6);
            ps.setString(7, in7);

            ps.execute();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery8(Connection conn, String sql, String in1,
            String in2, String in3, String in4, String in5, String in6,
            String in7, String in8) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);
            ps.setString(3, in3);
            ps.setString(4, in4);
            ps.setString(5, in5);
            ps.setString(6, in6);
            ps.setString(7, in7);
            ps.setString(8, in8);

            ps.execute();

            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, typically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery9(Connection conn, String sql, String in1,
            String in2) {
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, in1);
            ps.setString(2, in2);

            ResultSet rs = ps.executeQuery();

            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("This is a new run");
        Connection conn = initializeDB(DATABASE);

        /*
         * Menu
         */
        System.out.println("1)SEARCH");
        System.out.println("2)ADD NEW RECORDS");
        System.out.println("3)ORDER ITEMS");
        System.out.println("4)EDIT RECORDS");
        System.out.println("5)USEFUL REPORTS");
        System.out.println("6)QUIT");
        System.out.print("Enter input: ");
        int input1 = in.nextInt();

        while (input1 != 6) {

            /*
             * Search
             */
            if (input1 == 1) {
                System.out.println("1)ARTIST");
                System.out.println("2)TRACKS");
                System.out.print("Enter input: ");
                int input2 = in.nextInt();

                /*
                 * Searches for Artist
                 */
                if (input2 == 1) {
                    System.out.print("Enter Artist first name: ");
                    in.nextLine();
                    String input3 = in.nextLine();

                    System.out.print("Enter Artist last name: ");
                    String input4 = in.nextLine();

                    sqlQuery(conn, sqlStatement1, input3, input4);
                }
                /*
                 * Searches for track
                 */
                else if (input2 == 2) {
                    System.out.print("Enter Track title: ");
                    in.nextLine();
                    String input3 = in.nextLine();
                    sqlQuery1(conn, sqlStatement2, input3);
                } else {
                    System.out.print("Enter valid input");
                }
            }
            /*
             * Add New records
             */
            else if (input1 == 2) {
                System.out.println("1)ADD AN ARTIST");

                System.out.print("Enter ArtistId (10 digits): ");
                in.nextLine();
                String input3 = in.nextLine();

                System.out.print("Enter Artist first name: ");
                String input4 = in.nextLine();

                System.out.print("Enter Artist last name: ");
                String input5 = in.nextLine();

                sqlQuery2(conn, sqlStatement3, input3, input4, input5);
            }
            /*
             * Order items
             */
            else if (input1 == 3) {
                System.out.println("1)ORDER A MOVIE");
                System.out.println("2)ACTIVATE ITEM RECIEVED");
                System.out.print("Enter input: ");
                int input2 = in.nextInt();

                /*
                 * Orders a movie to library
                 */
                if (input2 == 1) {
                    System.out.println("1) Order new Movie");
                    System.out.println("2) Order existant Movie");
                    in.nextLine();
                    int input6 = in.nextInt();

                    /*
                     * New Movie
                     */
                    if (input6 == 1) {
                        System.out.print("Enter new Movie to order: ");
                        in.nextLine();
                        String input4 = in.nextLine();

                        System.out.print(
                                "Enter MediaId for the Movie (15 digits): ");
                        String input3 = in.nextLine();

                        System.out.print("Enter price of Movie ordered: ");
                        String input5 = in.nextLine();

                        System.out
                                .print("Enter Arrival Date of Movie ordered: ");
                        String input7 = in.nextLine();

                        System.out.print("Enter copies of Movie: ");
                        String input8 = in.nextLine();

                        sqlQuery5(conn, sqlStatement4, input3, input4, input5,
                                input7);

                        sqlQuery2(conn, sqlStatement56, input3, input4, input8);
                    } else {
                        sqlQuery0(conn, sqlStatement31);

                        System.out.print("Enter Movie to order: ");
                        in.nextLine();
                        String input4 = in.nextLine();

                        System.out.print(
                                "Enter MediaId for the Movie (15 digits): ");
                        String input3 = in.nextLine();

                        System.out.print("Enter price of Movie ordered: ");
                        String input7 = in.nextLine();

                        System.out
                                .print("Enter Arrival Date of Movie ordered: ");
                        String input8 = in.nextLine();

                        sqlQuery6(conn, sqlStatement41, input3, input4, input7,
                                input8);
                    }

                }
                /*
                 * Recieves a media item
                 */
                else if (input2 == 2) {
                    System.out.println("What kind of Media was recieved: ");
                    System.out.println("1) Movie ");
                    System.out.println("2) Book ");
                    System.out.println("3) Album ");
                    System.out.println("4) Track ");
                    System.out.println("5) Audiobook ");
                    System.out.print("Enter input: ");
                    in.nextLine();
                    int input3 = in.nextInt();

                    /*
                     * Receiving Movie
                     */
                    if (input3 == 1) {
                        System.out.println("1) New Movie");
                        System.out.println("2) Existant Movie");
                        in.nextLine();
                        int input0 = in.nextInt();

                        if (input0 == 1) {
                            System.out.print(
                                    "What Media_ID was recieved (15 digits): ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print(
                                    "What Movie_ID was recieved (10 digits): ");
                            String input5 = in.nextLine();

                            System.out.print("What Genre was recieved: ");
                            String input6 = in.nextLine();

                            System.out.print("What Movie was recieved: ");
                            String input7 = in.nextLine();

                            System.out.print("What year was the movie made: ");
                            String input8 = in.nextLine();

                            System.out.print("What length was the movie: ");
                            String input9 = in.nextLine();

                            System.out
                                    .print("What rating does the movie have: ");
                            String input10 = in.nextLine();

                            sqlQuery7(conn, sqlStatement51, input4, input5,
                                    input6, input7, input8, input9, input10);

                            sqlQuery12(conn, sqlStatement58, input7);

                            sqlQuery12(conn, sqlStatement57, input7);

                        } else {
                            System.out.print("What Movie was recieved: ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print("How many copies were recieved: ");
                            String input5 = in.nextLine();

                            sqlQuery3(conn, sqlStatement14, input5, input4);

                            sqlQuery12(conn, sqlStatement58, input4);

                            sqlQuery12(conn, sqlStatement57, input4);

                        }
                    }
                    /*
                     * Receiving Book
                     */
                    else if (input3 == 2) {
                        System.out.println("1) New Book");
                        System.out.println("2) Existant Book");
                        in.nextLine();
                        int input0 = in.nextInt();

                        if (input0 == 1) {
                            System.out.print(
                                    "What Media_ID was recieved (15 digits): ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print(
                                    "What Book_ID was recieved (10 digits): ");
                            String input5 = in.nextLine();

                            System.out.print("What Genre was recieved: ");
                            String input6 = in.nextLine();

                            System.out.print("What Book was recieved: ");
                            String input7 = in.nextLine();

                            System.out.print("What year was the book made: ");

                            String input8 = in.nextLine();

                            System.out.print("What length was the book: ");

                            String input9 = in.nextLine();

                            System.out.print(
                                    "What Author_ID was recieved (10 digits): ");

                            String input10 = in.nextLine();

                            sqlQuery7(conn, sqlStatement52, input4, input5,
                                    input6, input7, input8, input9, input10);

                            sqlQuery12(conn, sqlStatement58, input7);

                            sqlQuery12(conn, sqlStatement57, input7);
                        } else {
                            System.out.print("What Book was recieved: ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print("How many copies were recieved: ");
                            String input5 = in.nextLine();

                            sqlQuery3(conn, sqlStatement14, input5, input4);

                            sqlQuery12(conn, sqlStatement58, input4);

                            sqlQuery12(conn, sqlStatement57, input4);
                        }
                    }
                    /*
                     * Receiving Album
                     */
                    else if (input3 == 3) {
                        System.out.println("1) New Album");
                        System.out.println("2) Existant Album");
                        in.nextLine();
                        int input0 = in.nextInt();

                        if (input0 == 1) {
                            System.out.print(
                                    "What Media_ID was recieved (15 digits): ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print(
                                    "What Album_ID was recieved (10 digits): ");

                            String input5 = in.nextLine();

                            System.out.print("What Genre was recieved: ");

                            String input6 = in.nextLine();

                            System.out.print("What Album was recieved: ");

                            String input7 = in.nextLine();

                            System.out.print("What year was the Album made: ");

                            String input8 = in.nextLine();

                            System.out.print(
                                    "What length was the Album recieved: ");

                            String input9 = in.nextLine();

                            System.out.print(
                                    "What Artist_ID was recieved (10 digits): ");

                            String input10 = in.nextLine();

                            sqlQuery7(conn, sqlStatement53, input4, input5,
                                    input6, input7, input8, input9, input10);

                            sqlQuery12(conn, sqlStatement58, input7);

                            sqlQuery12(conn, sqlStatement57, input7);
                        } else {
                            System.out.print("What Album was recieved: ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print("How many copies were recieved: ");
                            String input5 = in.nextLine();

                            sqlQuery3(conn, sqlStatement14, input5, input4);

                            sqlQuery12(conn, sqlStatement58, input4);

                            sqlQuery12(conn, sqlStatement57, input4);
                        }
                    }
                    /*
                     * Receiving Track
                     */
                    else if (input3 == 4) {
                        System.out.println("1) New Track");
                        System.out.println("2) Existant Track");
                        in.nextLine();
                        int input0 = in.nextInt();

                        if (input0 == 1) {
                            System.out.print(
                                    "What Track_ID was recieved (10 digits): ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print(
                                    "What Album_ID was recieved (10 digits): ");

                            String input5 = in.nextLine();

                            System.out.print(
                                    "What Artist_ID was recieved (10 digits): ");

                            String input6 = in.nextLine();

                            System.out.print("What Genre was recieved: ");

                            String input7 = in.nextLine();

                            System.out.print("What track was recieved: ");

                            String input8 = in.nextLine();

                            System.out.print("What year was the track made: ");

                            String input9 = in.nextLine();

                            System.out.print(
                                    "What length was the track recieved: ");

                            String input10 = in.nextLine();

                            sqlQuery7(conn, sqlStatement54, input4, input5,
                                    input6, input7, input8, input9, input10);

                            sqlQuery12(conn, sqlStatement58, input8);

                            sqlQuery12(conn, sqlStatement57, input8);
                        } else {
                            System.out.print("What Track was recieved: ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print("How many copies were recieved: ");
                            String input5 = in.nextLine();

                            sqlQuery3(conn, sqlStatement14, input5, input4);

                            sqlQuery12(conn, sqlStatement58, input4);

                            sqlQuery12(conn, sqlStatement57, input4);
                        }
                    }
                    /*
                     * Receiving Audiobook
                     */
                    else if (input3 == 5) {
                        System.out.println("1) New Audiobook");
                        System.out.println("2) Existant Audiobook");
                        in.nextLine();
                        int input0 = in.nextInt();

                        if (input0 == 1) {
                            System.out.print(
                                    "What Media_ID was recieved (15 digits): ");
                            in.nextLine();
                            String input4 = in.nextLine();

                            System.out.print(
                                    "What AudioBook_ID was recieved (10 digits): ");

                            String input5 = in.nextLine();

                            System.out.print("What Genre was recieved: ");

                            String input6 = in.nextLine();

                            System.out.print("What AudioBook was recieved: ");

                            String input7 = in.nextLine();

                            System.out.print("What year was the book made: ");

                            String input8 = in.nextLine();

                            System.out.print(
                                    "What length was the book recieved: ");

                            String input9 = in.nextLine();

                            System.out.print(
                                    "How many chapters are in the book recieved: ");

                            String input10 = in.nextLine();

                            System.out.print(
                                    "What Author_ID was recieved (10 digits): ");

                            String input11 = in.nextLine();

                            sqlQuery8(conn, sqlStatement55, input4, input5,
                                    input6, input7, input8, input9, input10,
                                    input11);

                            sqlQuery12(conn, sqlStatement58, input7);

                            sqlQuery12(conn, sqlStatement57, input7);
                        }
                    } else {
                        System.out.print("What Audiobook was recieved: ");
                        in.nextLine();
                        String input4 = in.nextLine();

                        System.out.print("How many copies were recieved: ");
                        String input5 = in.nextLine();

                        sqlQuery3(conn, sqlStatement14, input5, input4);

                        sqlQuery12(conn, sqlStatement58, input4);

                        sqlQuery12(conn, sqlStatement57, input4);
                    }
                } else {
                    System.out.print("Enter valid input");
                }
            }
            /*
             * Edit records
             */
            else if (input1 == 4) {
                System.out.println("1)EDIT AN ARTIST");
                System.out.print("Enter Artists first name: ");
                in.nextLine();
                String input3 = in.nextLine();

                System.out.print("Enter Artists last name: ");
                String input6 = in.nextLine();

                System.out.println("1)EDIT ARTIST ID");
                System.out.println("2)EDIT ARTIST FNAME");
                System.out.println("3)EDIT ARTIST LNAME");
                System.out.print("Enter input: ");
                int input4 = in.nextInt();

                /*
                 * Art_ID
                 */
                if (input4 == 1) {
                    System.out.print("What would you like ArtistId to be: ");
                    in.nextLine();
                    String input5 = in.nextLine();

                    sqlQuery2(conn, sqlStatement7, input5, input3, input6);
                }
                /*
                 * Fname
                 */
                else if (input4 == 2) {
                    System.out.print("What would you like Fname to be: ");
                    in.nextLine();
                    String input5 = in.nextLine();

                    sqlQuery2(conn, sqlStatement8, input5, input3, input6);
                }
                /*
                 * Lname
                 */
                else if (input4 == 3) {
                    System.out.print("What would you like Lname to be: ");
                    in.nextLine();
                    String input5 = in.nextLine();

                    sqlQuery2(conn, sqlStatement6, input5, input3, input6);
                } else {
                    System.out.println("Enter valid input");
                }
            }
            /*
             * Useful reports
             */
            else if (input1 == 5) {
                System.out.println("1)Tracks by ARTIST released before YEAR");
                System.out.println(
                        "2)Number of albums checked out by a single patron");
                System.out.println("3)Most popular actor in the database");
                System.out.println("4)Most listened to artist in the database");
                System.out.println(
                        "5)Patron who has checked out the most videos");
                System.out.print("Enter input: ");
                int input2 = in.nextInt();

                if (input2 == 1) {
                    System.out.print("Enter Artist First Name: ");
                    in.nextLine();
                    String input3 = in.nextLine();

                    System.out.print("Enter Artist Last Name: ");
                    String input4 = in.nextLine();

                    System.out.print("Enter Year: ");
                    String input5 = in.nextLine();

                    sqlQuery4(conn, sqlStatement9, input3, input4, input5);
                } else if (input2 == 2) {
                    System.out.print("Enter Patron First Name: ");
                    in.nextLine();
                    String input3 = in.nextLine();

                    System.out.print("Enter Patron Last Name: ");
                    String input4 = in.nextLine();

                    sqlQuery9(conn, sqlStatement10, input3, input4);

                } else if (input2 == 3) {
                    sqlQuery0(conn, sqlStatement11);

                } else if (input2 == 4) {
                    sqlQuery0(conn, sqlStatement12);

                } else if (input2 == 5) {
                    sqlQuery0(conn, sqlStatement13);
                } else {
                    System.out.println("Enter valid input");
                }

            } else {
                System.out.println("Enter valid input");
            }

            System.out.println("1)SEARCH");
            System.out.println("2)ADD NEW RECORDS");
            System.out.println("3)ORDER ITEMS");
            System.out.println("4)EDIT RECORDS");
            System.out.println("5)USEFUL REPORTS");
            System.out.println("6)QUIT");
            System.out.print("Enter input: ");
            input1 = in.nextInt();

        }
        in.close();

    }

}
